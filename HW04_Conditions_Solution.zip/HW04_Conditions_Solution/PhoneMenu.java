//CS200
//Spring 2015
//Instructor: Y. Gutstein 
//HW #3: Phone Menu
//Due: Week 4
//File name: PhoneMenu.java

import java.util.Scanner;

public class PhoneMenu{
	public static void main(String[] args){
		int deptMenu;		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Hello.  You have reached Studio Y Architecture.");
		System.out.println("For the Residential Design Department, please press 1.");
		System.out.println("For the Educational Design Department, please press 2.");
		System.out.println("For the Kitchen Design Department, please press 3.");
		System.out.println("For the Structural Design Department, please press 4.");
		System.out.println("For the Human Resources Department, please press 5.");
		System.out.println("For the Accounting Department, please press 6.");
		
		deptMenu = keyboard.nextInt();
		
	 	if ((deptMenu < 1) || (deptMenu > 6)){
			System.out.println("I'm sorry.  You have made an invalid entry.  Goodbye.");
		} //if ((deptMenu < 1) || (deptMenu > 6))				
		else if (deptMenu == 1){
			System.out.println("Hi.  You have reached the Architectural Design Department.");
			System.out.println("We have a roof over our heads, so we're grateful. Do you?");
			System.out.println("Maybe that's why you need our services.  Leave us a message.");
		} //else if (deptMenu == 1)
		else if (deptMenu == 2){
			System.out.println("Hi.  You have reached the Educational Design Department.");
			System.out.println("We went to school in a building that someone else designed.");
			System.out.println("Now it's time for us to design your school. Leave us a message.");
		} //else if (deptMenu == 2)
		else if (deptMenu == 3){
			System.out.println("Hi.  You have reached the Kitchen Design Department.");
			System.out.println("We're busy eating in our kitchen, since we have one and you don't...yet.");
			System.out.println("Leave us a message.");
		} //else if (deptMenu == 3)	
		else if (deptMenu == 4){
			System.out.println("Hi.  You have reached the Structural Design Department.");
			System.out.println("We're trying to make sure your building won't collapse on you.");
			System.out.println("Leave us a message.");
		} //else if (deptMenu == 4)
		else if (deptMenu == 5){
			System.out.println("Hi.  You have reached the Human Resources Department.");
			System.out.println("Unfortunately, we're not hiring.  Fortunately, we're not firing.");
			System.out.println("Leave us your info and we'll find room for you as soon as we can.");				
		} //else if (deptMenu == 5)
		else{
			System.out.println("Hi.  You have reached the Accounting Department.");
			System.out.println("We're busy trying to keep the firm's numbers in the black.");
			System.out.println("Ain't easy in this economy.  Leave us a message.");
		} //else				
	
	} //close main
} //close PhoneMenu