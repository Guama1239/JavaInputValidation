
public class Operations {

	public static void main(String[] args) {
		int c = 3729, d = 22, e = 34, f = 67;
		System.out.println(e + " * " + f + " is " + multiply(e, f));
		System.out.println(c + " / " + d + " is " + divide(c, d));
	}

	public static int add(int a, int b){
		return a + b;
	}
	
	public static int subtract(int a, int b){
		return add(a, -1 * b);
	}
	
	public static int multiply(int a, int b){
		int sum = 0;
		for (int i = 1; i <= b; i++){
			sum = add(sum, a);
		}
		return sum;
	}
	
	public static int divide(int a, int b){
		int sub = a;
		int i = 0;
		while (sub >= b){
			i++;
			sub = subtract(sub, b);
		}
		return i;
	}

}
