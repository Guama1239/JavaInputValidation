import java.util.Scanner;
public class SortNumbers {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		int num1 = 0, num2 = 0, num3 = 0;
		for(int count = 1; count <=3; count++){
			System.out.print("Enter a number: ");
			if(count == 1)
				num1 = keyboard.nextInt();
			else if(count ==2)
				num2 = keyboard.nextInt();
			else
				num3 = keyboard.nextInt();
		}
		displaySortedNumbers(num1, num2, num3);
	}

	public static void displaySortedNumbers(int a, int b, int c){
		if (a < b && b < c)
			System.out.println(a + " " + b + " " + c);
		else if (a < c && c < b)
			System.out.println(a + " " + c + " " + b);
		else if (b < a && a < c)
			System.out.println(b + " " + a + " " + c);
		else if (b < c && c < a)
			System.out.println(b + " " + c + " " + a);
		else if (c < a && a < b)
			System.out.println(c + " " + a + " " + b);
		else
			System.out.println(c + " " + b + " " + a);
	}

}
