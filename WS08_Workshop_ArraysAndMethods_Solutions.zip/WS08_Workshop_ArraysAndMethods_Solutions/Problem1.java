import java.util.Scanner;

public class Problem1
{
	public static void main(String[] args)
	{
		int[] a1 = { 1, 2, 3 };
		int n1 = maxThree(a1);
		int[] a2 = { -8, -7, -2, 1,-3 };
		int n2 = maxThree(a2);	
		int[] a3 = { 9 };
		int n3 = maxThree(a3);
		System.out.println(n1 + "\n" + n2 + "\n" + n3);
	}
	
	public static int maxThree(int[] a)
	{
		int first = a[0];
		int last = a[a.length - 1];
		int ind = a.length/2;
		int mid = a[ind];
		
		int max = Math.max(first, mid);
		max = Math.max(max, last);
		return max;
	}
}