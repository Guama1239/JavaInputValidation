import java.util.Scanner;

public class OpenTriangle {
	public static void main(String[] args){
		Scanner keyboard = new Scanner(System.in);
		int input;
		
		System.out.print("Enter a triangle height greater than 1: ");
		input = keyboard.nextInt();
		
		for(int row = 1; row <= input; row++){
			for(int col = 1; col <= row; col++){
				if(col == row)
					System.out.print("*");
				else if(col == 1)
					System.out.print("* ");
				else{
					if(row == input)
						System.out.print("* ");
					else
						System.out.print("  ");
				}
			}
			System.out.println();
		}
	}
}
