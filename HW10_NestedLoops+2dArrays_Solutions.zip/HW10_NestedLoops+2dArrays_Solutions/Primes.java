import java.util.Scanner;
public class Primes {

	public static void main(String[] args){
int petal = 7, leaf = 2, stem = 0, seed; boolean grow = true;
for (seed = 10; seed > 7; seed--){
if (seed > petal) System.out.println("seed " + seed);
else{
System.out.println("petal " + petal); leaf++;
} }
System.out.println(); System.out.println("grow " + seed * leaf);
for(stem = 0; stem < 2; stem++){ System.out.println("water " + stem); for (seed = 0; seed <= 2; seed++){
System.out.print(seed + " "); }
System.out.println();
System.out.println("flowers " + stem); }
} // end of main

}
