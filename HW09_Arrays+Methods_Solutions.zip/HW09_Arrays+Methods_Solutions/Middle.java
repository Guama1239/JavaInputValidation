
public class Middle {

	public static void main(String[] args) {
		int[] arr1 = {1,2,3,4};
		int[] arr2 = {7,1,3,2,4,9};
		int[] arr3 = {1,2};
		int[] result = makeMiddle(arr1);
		for(int i = 0; i < result.length; i++){
			System.out.print(result[i]);
			if(i < result.length - 1)
				System.out.print(", ");			
		}
		System.out.println();
		result = makeMiddle(arr2);
		for(int i = 0; i < result.length; i++){
			System.out.print(result[i]);
			if(i < result.length - 1)
				System.out.print(", ");			
		}
		System.out.println();
		result = makeMiddle(arr3);
		for(int i = 0; i < result.length; i++){
			System.out.print(result[i]);
			if(i < result.length - 1)
				System.out.print(", ");			
		}
	}

	private static int[] makeMiddle(int[] arr) {
		int[] result = {arr[arr.length/2 - 1], arr[arr.length/2]};
		return result;
	}
}
