import java.util.Scanner;
public class FirstLast {

	public static void main(String[] args) {
		int[] arr1 = {1,2,3};
		int[] arr2 = {1,2,3,1};
		int[] arr3 = {1,2,1};
		System.out.println(sameFirstLast(arr1));
		System.out.println(sameFirstLast(arr2));
		System.out.println(sameFirstLast(arr3));
	}
	
	private static boolean sameFirstLast(int[] arr) {
		if(arr.length > 1)
			if(arr[0] == arr[arr.length-1])
				return true;
			else
				return false;
		else
			return false;
	}
}

	