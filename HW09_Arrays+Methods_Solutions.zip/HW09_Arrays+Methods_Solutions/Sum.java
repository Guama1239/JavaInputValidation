
public class Sum {

	public static void main(String[] args) {
		int[] arr1 = {1,2,3};
		int[] arr2 = {1,2,3,1};
		int[] arr3 = {1,22};
		System.out.println(sumAll(arr1));
		System.out.println(sumAll(arr2));
		System.out.println(sumAll(arr3));
	}

	private static int sumAll(int[] arr) {
		int sum = 0;
		for(int i = 0; i < arr.length; i++){
			sum += arr[i];
		}
		return sum;
	}
}
