//CS200
//Spring 2019
//Luis Rosales
//Instructor: Y. Gutstein 
//HW #5: BooleansPhone Menu
//Due: Week 5 Booleans
//File name: IfElse.java

import java.util.Scanner;

public class IfElse{
	public static void main(String[] args){
		int MenuOption;		
		Scanner kbd = new Scanner(System.in);
		
		System.out.println("Hello.  You have reached InterDev Software Solutions.");
		System.out.println("For the Java Softaware Solutions Department, please press 1.");
		System.out.println("For the Python Software Solutions Department, please press 2.");
		System.out.println("For the Javascript Software Solution Department, please press 3.");
		System.out.println("For the Ruby Software Solution Department, please press 4.");
		System.out.println("For the Cobol Software Solution Department, please press 5.");
		System.out.println("For the C++ Software Solution Department, please press 6.");
		
		MenuOption = kbd.nextInt();
		
	 	if ((MenuOption < 1) || (MenuOption > 6)){
			System.out.println("I'm sorry.  You have made an invalid entry or we do not program in that very old, obsolete Pascal Language.  Goodbye.");
		} //if ((MenuOption < 1) || (MenuOption > 6))				
		else if (MenuOption == 1){
			System.out.println("Hi.  You have reached the Java Software Solutions Department.");
			System.out.println("This phone book runs on Java and for that we are grateful, are you?");
			System.out.println("Maybe that's why you need our services.  Leave us a message.");
		} //else if (MenuOption == 1)
		else if (MenuOption == 2){
			System.out.println("Hi.  You have reached the Python Software Solutions Department.");
			System.out.println("We believe the results of data analysis others run for us.");
			System.out.println("Now it's time for us to design your own data analysis. Leave us a message.");
		} //else if (MenuOption == 2)
		else if (MenuOption == 3){
			System.out.println("Hi.  You have reached the Javascript Software Solutions Department.");
			System.out.println("We're busy deploying our WebSite to HEROKU, since we will have one and you won't...yet.");
			System.out.println("Leave us a message.");
		} //else if (MenuOption == 3)	
		else if (MenuOption == 4){
			System.out.println("Hi.  You have reached the Ruby Software Solutions Department.");
			System.out.println("We're trying to figure out how Ruby works.");
			System.out.println("Leave us a message.");
		} //else if (MenuOption == 4)
		else if (MenuOption == 5){
			System.out.println("Hi.  You have reached the Cobol Software Solutions Department.");
			System.out.println("If you are a FRUGAL Bank who is reluctant to get away from Cobol. Then you are lucky you found us.");
			System.out.println("Do not leave us your info, we know who you are. Call you soon.");				
		} //else if (MenuOption == 5)
		else{
			System.out.println("Hi.  You have reached the C++ Software Solutions Department.");
			System.out.println("We're busy trying to help the other Departments.");
			System.out.println("Ain't easy with some peoples' work ethic.  Leave us a message.");
		} //else				
	
	} //close main
} //close IfElse