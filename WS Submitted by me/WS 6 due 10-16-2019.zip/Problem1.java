/************
* CS200
* Fall, 2019
* Luis Rosales
* Instructor: Y. Gutstein
* 
* WS6 Problem 1 due 10/16/2019
* File name: Problem1.java
************/

import java.util.Scanner;// requests unser input

public class Problem1
{
   public static void main (String []  args){
      Scanner kbd = new Scanner(System.in);
      System.out.print(" Enter a number: ");
      int num1 = kbd.nextInt();//captures number1
      System.out.print(" Enter another number: ");   
      int num2 = kbd.nextInt();// gets second number
      System.out.println("Return value is " + maxMod5(num1, num2));
   }
   
   public static int maxMod5(int n1, int n2){
      int result = 0;
      
      if (n1 == n2) return result;
      else if ((n1 % 5 == 0) && (n2%5 == 0)) 
      result = Math.min(n1,n2);
      else result = Math.max(n1,n2);
      return result;   
   }
}