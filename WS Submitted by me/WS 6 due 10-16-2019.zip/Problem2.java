/************
* CS200
* Fall, 2019
* Luis Rosales
* Instructor: Y. Gutstein
* 
* WS6 Problem 2 due 10/16/2019
* File name: Problem2.java
************/

import java.util.Scanner;// requests unser input

public class Problem2
{
   public static void main (String []  args){
      Scanner kbd = new Scanner(System.in);
      System.out.print(" Enter a number: ");
      int num1 = kbd.nextInt();//captures number1
      System.out.print(" Enter another number: ");   
      int num2 = kbd.nextInt();// gets second number
      System.out.print(" Enter the last number: ");
      int num3 = kbd.nextInt();//captures third number
      
      System.out.println("Return value is " + evenlySpaced(num1, num2, num3));
   }
   
   public static boolean evenlySpaced(int n1, int n2, int n3){
      boolean result = false;
      
      int tempSmall = Math.min(n1,n2);
      int small = Math.min(n3, tempSmall);
      
      int tempLarge = Math.max(n1,n2);
      int large = Math.max(n3,tempLarge);
      
      int middle;
      if (n1 > small && n1 < large)
         middle = n1;
      else if (n2 > small && n2 < large)
         middle = n2;
      else
         middle = n3;
         
      if ( middle - small == large - middle)
         result = true;
         
      return result;   
   }
}