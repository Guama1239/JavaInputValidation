/************
* CS200
* Fall, 2019
* Luis Rosales
* Instructor: Y. Gutstein
* 
* WS6 Problem 3 due 10/16/2019
* File name: Problem3.java
************/

import java.util.Scanner;// requests unser input

public class Problem3
{
   public static void main (String []  args){
      Scanner kbd = new Scanner(System.in);
      System.out.print(" Enter a number: ");
      int num1 = kbd.nextInt();//captures number1
      System.out.print(" Enter another number: ");   
      int num2 = kbd.nextInt();// gets second number
      
      System.out.println("Return value is " + sumProduct(num1, num2));
   }
   
   public static String  sumProduct(int n1, int n2){
      String value = "";
           
      if ((n1 % 8 == 0 ) && (n2 % 8 == 0 ))
         value = " Awesome ";
      else if ((n1 + n2) > (n1*n2))
           value = " Sum ";
      else if ((n1 + n2) < (n1*n2)) value = " Product ";
      else if (n1 == n2) value = " Tie ";
      
      return value;
   }
}
   