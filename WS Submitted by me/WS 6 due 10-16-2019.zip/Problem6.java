/************
* CS200
* Fall, 2019
* Luis Rosales
* Instructor: Y. Gutstein
* 
* WS6 Problem 6 due 10/16/2019
* File name: Problem6.java
************/
   
import java.util.Scanner;
public class Problem6
{
	public static void main(String[] args)
	{
		   int n1 = 15;
      	int n2 = 99;
      	int n3 = 20;

		
		   System.out.println("Sum is: " + sumOfDigits(n1));
      	System.out.println("Sum is: " + sumOfDigits(n2));
      	System.out.println("Sum is: " + sumOfDigits(n3));
	}
	
	public static int sumOfDigits(int a)
	{
      int sum = 0;
      if ((a > 99) && (a < 1000))// fixed for 100th numbers or 3 digits numbers
         sum = a / 100;
		sum += a % 10;
		sum += a / 10;
		
		return sum;
	}
}