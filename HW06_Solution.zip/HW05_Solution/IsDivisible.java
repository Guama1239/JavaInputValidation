import java.util.Scanner;

public class IsDivisible
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
      
      int dividend, divisor;
      
      System.out.print("Please enter the dividend: ");
      dividend = keyboard.nextInt();
      System.out.print("Please enter the divisor: ");
      divisor = keyboard.nextInt();
      
      if (dividend % divisor == 0)
         System.out.println(dividend + " is divisible by " + divisor);
      else
         System.out.println(dividend + " is not divisible by " + divisor);
   }
}