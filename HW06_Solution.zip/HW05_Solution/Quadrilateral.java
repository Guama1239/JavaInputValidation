import java.util.Scanner;

public class Quadrilateral
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
      double length, width;
      
      System.out.print("Enter the length: ");
      length = keyboard.nextDouble();
      System.out.print("Enter the width: ");
      width  = keyboard.nextDouble();
      
      if (width == length)
         System.out.println("It's a square!");
      else
         System.out.println("It's a rectangle!");
      
      width++; 
      System.out.println("The width is now " + width);
      
      if (width == length)
         System.out.println("It's a square!");
      else
         System.out.println("It's a rectangle!");
   }
}