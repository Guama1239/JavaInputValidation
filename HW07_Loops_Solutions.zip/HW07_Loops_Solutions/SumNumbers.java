public class SumNumbers
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        
        int num;
        S.O.P("Enter a number greater than 1: ");
        num = keyboard.nextInt();

        int count = 1;
        int sum = 0;

        while (count <= num) 
        {
            sum = sum + count;
            count = count + 1;
        }

        S.O.P.L("The sum is " + sum);
    }
}  