public class Scores
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        
        double score = 0;
        double sum = 0;
        int numberOfGrades = 0;

        while (score != -1) 
        {
            System.out.print("Enter a score between 0 and 100 or -1 to exit: ");
            score = keyboard.nextDouble();
            
            if (score != -1)
            {
                sum = sum + score;
                numberOfGrades++;
            }    
        }

        double average = sum/numberOfGrades;
        System.out.println("The average is " + average);
    } 
}    
