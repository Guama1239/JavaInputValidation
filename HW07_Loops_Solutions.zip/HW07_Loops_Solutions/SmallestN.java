import java.util.Scanner;

public class SmallestN {
	public static void main(String[] args){
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter a number larger than 10: ");
		int input = keyboard.nextInt();
		
		boolean smaller = true;
		int n = 0;
		
		while(smaller){
			n++;
			if((n * n) > input)
				smaller = false;			
		}
		
		System.out.println("The smallest value for n that gives " +
				"n * n > " + input + " is " + n);
	}
}
