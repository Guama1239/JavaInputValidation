import java.util.Scanner;

public class DivisibleLines {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter a number larger than 20: ");
		int input = keyboard.nextInt();
		
		int num = 2, count = 0;
		
		while(num <= input){
			if(num % 2 == 0 || num % 3 == 0){
				if(!(num % 2 == 0 && num % 3 == 0)){
					count++;
					if(count % 10 == 0)
						System.out.println(num);
					else
						System.out.print(num + " ");	
				}
			}
			num++;
		}

	}

}
