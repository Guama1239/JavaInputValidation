//CS200
//Spring 2015
//Instructor: Y. Gutstein 
//HW #2: Pizza
//Due: Week 3
//File name: Pizza.java 


class Pizza{//open  class Pizza
	public static void main (String args[]){//open method main
	
	int sizePizzaSmall = 7;//size of 1st pizza
	int sizePizzaLarge = 14;//size of 2nd pizza
	int numberOfPizzasSmall = 2;//original number of 7 inch pizzas
	int numberOfPizzasLarge = 1;//orignal number of 14 inch pizzas
	int people = 6;//total number of people eating pizza in the 3rd problem
	
	double sq_inchesOfPizzaSmall, sq_inchesOf2PizzaSmall, sq_inchesOfPizzaLarge, 
			 sq_inchesOfPizzaMore, radiusOfPizzaSmall, radiusOfPizzaLarge, pizzaToMyself;
	
		
		radiusOfPizzaSmall = (double)sizePizzaSmall / 2;//diameter of the pizza divided by 2
		sq_inchesOfPizzaSmall = Math.PI * Math.pow(radiusOfPizzaSmall, 2.0);//area of a circle = PI(r^2)
		sq_inchesOf2PizzaSmall = sq_inchesOfPizzaSmall * 2;
		
		radiusOfPizzaLarge = (double)sizePizzaLarge / 2;//diameter of the pizza divided by 2
		sq_inchesOfPizzaLarge = Math.PI * Math.pow(radiusOfPizzaLarge, 2.0);//area of a circle = PI(r^2)
		
      //System.out.println((double)people + "-" + people);
		System.out.print("Who's hungry? ");
		System.out.println("I'm Starving! " + "Let's order some pizza! ");
		System.out.println("I will get " + sq_inchesOf2PizzaSmall  + 
                        " square inches of pizza when I order "  
								+ numberOfPizzasSmall + " - " + sizePizzaSmall 
                        + " inch pizzas,");
		System.out.println("and I will get " + sq_inchesOfPizzaLarge  
                        + " square inches of pizza when I order " 
								+ numberOfPizzasLarge + " - " + sizePizzaLarge 
                        + " inch pizza.");
		
		numberOfPizzasSmall = 1;//number of 7 inch pizzas for the second part of the problem
		sq_inchesOfPizzaMore = sq_inchesOfPizzaLarge - sq_inchesOfPizzaSmall;;//subtract 7-inch from 14-inch
		System.out.println("I will get " + sq_inchesOfPizzaMore  
                        + " square inches more pizza when I order " 
								+ numberOfPizzasLarge + " - " + sizePizzaLarge 
                        + " inch pizza");
		System.out.println("than I would get from ordering " 
                        + numberOfPizzasSmall + " - " + sizePizzaSmall  
								+ " inch pizza.");
								
		pizzaToMyself = sq_inchesOfPizzaLarge / (double)people;;//divide 14-inch pizza by 6 people eating the pizza
		
		System.out.println("If I order " + numberOfPizzasLarge+ " - " + sizePizzaLarge 
								+ " inch pizza and share it with " + (people - 1) + " friends,");
		System.out.println("I will get " + pizzaToMyself + " square inches to eat by myself.");
		System.out.println("That's enough to hold me till dessert! " + "Time to eat!");
		
	}//close method main
}//close class Pizza