import java.util.Scanner;

public class Height{

	public static void main(String[] args){
		Scanner keyboard = new Scanner(System.in);
		int height, feet, inches;

		System.out.print("Enter your heigh in inches: ");
		height = keyboard.nextInt();

		feet = height / 12;
		inches = height % 12;

		System.out.println("That is " + feet + " feet and " + inches + " inches.");
	}
}