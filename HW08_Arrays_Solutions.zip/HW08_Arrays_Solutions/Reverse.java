import java.util.Scanner;

public class Reverse {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		int[] array = new int[10];
		
		System.out.print("Enter 10 integers: ");
		for (int count = 0; count < array.length; count++) 
		{
			array[count] = input.nextInt();
		}
		
		System.out.print("The reverse is: ");
		for (int num = array.length - 1; num >= 0; num--) 
		{
			System.out.print(array[num] + " ");
		}
		System.out.println();
		
	}
}