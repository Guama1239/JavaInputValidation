import java.util.Scanner;

public class Identical {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	
		System.out.print("Enter the list length: ");
		int size = input.nextInt();
		int[] array1 = new int[size]; 
		int[] array2 = new int[size];
		
		System.out.print("Enter list 1: ");
		for (int count = 0; count < size; count++) 
		{
			array1[count] = input.nextInt();
		}
		
		System.out.print("Enter list 2: ");
		for (int count = 0; count < size; count++) 
		{
			array2[count] = input.nextInt();
		}
		
		int index = 0;
		boolean isIdentical = true;
		while (isIdentical && index < size) 
		{
			if (array1[index] != array2[index]) 
			{
				isIdentical = false;
			}
			index++;
		}
		
		if (isIdentical)
			System.out.println("The lists are identical.");
		else
			System.out.println("The lists are not identical.");
	}
}