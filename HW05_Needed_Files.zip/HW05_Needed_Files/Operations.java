public class Operations
{
	public static void main(String[] args)
	{
		int c = 3729, d = 22, e = 34, f = 67;
		//System.out.println(e + " * " + f + " is " + multiply(e, f));
		//System.out.println(c + " / " + d + " is " + divide(c, d));
	}
	
	public static int add(int a, int b)
	{
		return a + b;
	}
	
	public static int subtract(int a, int b)
	{
		return add(a, -1 * b);
	}

}