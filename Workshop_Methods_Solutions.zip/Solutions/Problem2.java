public class Problem2
{
	public static void main(String[] args)
	{
		boolean b1 = evenlySpaced(2, 4, 6);
		boolean b2 = evenlySpaced(4, 6, 2);
		boolean b3 = evenlySpaced(4, 6, 3);
		
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
	}
	
	public static boolean evenlySpaced(int a, int b, int c)
	{
		boolean space = false;
		
		int smTemp = Math.min(a, b);
		int small = Math.min(c, smTemp);
		
		int lgTemp = Math.max(a, b);
		int large = Math.max(c,lgTemp);
		
		int middle;
		if (a > small && a < large)
			middle = a;
		else if (b > small && b < large)
			middle = b;
		else
			middle = c;
		
		if ( middle - small == large - middle)
			space = true;
		
		return space;
	}
}