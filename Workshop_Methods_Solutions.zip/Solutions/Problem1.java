public class Problem1
{
	public static void main(String[] args)
	{
		int n1 = maxMod5(7, 5);
		int n2 = maxMod5(-4, 3);
		int n3 = maxMod5(6, 11);
		int n4 = maxMod5(8, 8);
		
		System.out.println(n1);
		System.out.println(n2);
		System.out.println(n3);
		System.out.println(n4);
	}
	
	public static int maxMod5(int a, int b)
	{
		int n;
		if (a == b)
			n = 0;
		else if ( a % 5  ==  b % 5 )
			n = Math.min(a, b);
		else
			n = Math.max(a, b);
			
		return n;
	}
}