import java.util.Scanner;
public class Problem5
{
	public static void main(String[] args)
	{
		int n1 = max(5, 5);
      	int n2 = max(-4, 3);
      	int n3 = max(6, 11);
      	int n4 = max(8, 2);
	
		
	}
	public static int max(int a, int b)
	{
		int max = a;
		
		if(a > b)
		{
			System.out.println("n1 is the max at: " + a);
			max = a;
		}
		else if(b > a)
		{
			System.out.println("n2 is the max at: " + b);
			max = b;
		}	
		else
			System.out.println("They are equal");
			
		return max;	
	}
}