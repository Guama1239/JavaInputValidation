public class Problem3
{
   public static void main(String[] args)
   {
   
      sumProduct(5, 1);
      System.out.println();
      sumProduct(64, 32);
      System.out.println();
      sumProduct(4, 2);
      System.out.println();
      sumProduct(2, 2);
      
   }
   
   public static String sumProduct(int a, int b)
   {
      int sum, product;
      
      sum = a + b;
      product = a * b;
      
      String s = "";
      
      if (sum % 8 == 0 && product % 8 == 0)
         s = "Awesome";
      else if (sum == product)
         s = "Tie";
      else if (sum > product)
         s = "Sum";
      else
         s = "Product";
    
      return s;    
   }
}