import java.util.Scanner;
public class Problem6
{
	public static void main(String[] args)
	{
		int n1 = 10;
      	int n2 = 99;
      	int n3 = 25;

		
		System.out.println("Sum is: " + sumOfDigits(n1));
      	System.out.println("Sum is: " + sumOfDigits(n2));
      	System.out.println("Sum is: " + sumOfDigits(n3));
	}
	
	public static int sumOfDigits(int a)
	{
		int sum = a % 10;;
		sum += a / 10;
		
		return sum;
	}
}