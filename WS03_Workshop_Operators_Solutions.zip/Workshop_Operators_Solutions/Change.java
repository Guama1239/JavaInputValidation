import java.util.Scanner;

public class Change
{
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		int cost;
		System.out.print("Enter the item cost: ");
		cost = kb.nextInt();
		
		int q, d, n, r;
		q = (100 - cost) / 25;
		r = (100 - cost) % 25;
		d = r / 10;
		r = r % 10;
		n = r / 5;
		
		System.out.println("Your change is: ");
		System.out.println(q + " quarters");
		System.out.println(d + " dimes");
		System.out.println(n + " nickels");
	}
}