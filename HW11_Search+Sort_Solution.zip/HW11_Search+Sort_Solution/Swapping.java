import java.util.Scanner;

public class Swapping
{
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		System.out.print("Total numbers to input? ");
		int total = kb.nextInt();
		
		System.out.print("Enter numbers: ");
		int[] array = new int[total];
		for (int i = 0; i < array.length; i++)
			array[i] = kb.nextInt();
		
		array = swapEnds(array);
		for (int i = 0; i < array.length; i++)
			System.out.print(array[i] + " ");
		System.out.println();
	}
	
	public static int[] swapEnds(int[] nums)
	{
		int temp = nums[0];
		nums[0] = nums[nums.length - 1];
		nums[nums.length - 1] = temp;
		return nums;
	}
}