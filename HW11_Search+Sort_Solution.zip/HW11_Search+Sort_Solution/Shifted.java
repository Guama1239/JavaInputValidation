import java.util.Scanner;

public class Shifted
{
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		System.out.print("Total numbers to input? ");
		int total = kb.nextInt();
		
		System.out.print("Enter numbers: ");
		int[] array = new int[total];
		for (int i = 0; i < array.length; i++)
			array[i] = kb.nextInt();
		
		array = shiftLeft(array);
		for (int i = 0; i < array.length; i++)
			System.out.print(array[i] + " ");
		System.out.println();
	}
	
	public static int[] shiftLeft(int[] nums)
	{
		int temp = nums[0];
		for (int i = 0; i < nums.length - 1; i++)
			nums[i] = nums[i + 1];
		
		nums[nums.length - 1] = temp;
		return nums;
	}
}